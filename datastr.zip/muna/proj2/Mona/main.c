
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <math.h>
    #define SIZE 100   // Define maximum number of characters in equation and the number of equations in the file.


    typedef struct StackNode* ptr;     // Pointer to a stack node.
    typedef ptr Stack ;                // Pointer to the header of a Stack.
    typedef ptr position;              // Pointer to position in the Stack.
    typedef struct Equation* Equation;        // Pointer to an Equation node.
    typedef struct Equality* Equality; // Pointer to an Equality node.



    /*
    * Stack is implemented using linked list concept.
    * this struct is used for both numbers and characters.
    * characters are pushed into the stack by their ASCII code,
    * and then casted to(char) when popped.
    */

    struct StackNode {
        float element;
        position next;
    };

    // struct Equation contains all the information related to an equation
    struct Equation {
        char originEq[SIZE];      //the origin equation
        char postFix[SIZE];       //the postfix notation of the equation
        int valid ;               // indicates the validity of the equation
        float result;             // the result of the equation if valid
        int exception;            // indicates if there is arithematic exceptions in the equation

    };

    // Equality is a two equations seperated by '='.
    struct Equality {
        Equation Eq[2];   // Array of two Equations.
    };


    // Functions Prototypes
    Stack createStack (void);
    int isEmpty(Stack s);
    void push(Stack s, float c);
    void pop(Stack s);
    float top(Stack s);
    int isDigit(char c);
    int isOperation(char c);
    int isOpenBrace(char c);
    int isCloseBrace(char c);
    int isSign(char c);
    int charType(char c);
    int checkFirstChar(char c , char next);
    int checkLastChar(char c);
    int checkAfterDigit(char c);
    int checkAfterOperation(char c);
    int checkAfterOpenBrace(char c, char next);
    int checkAfterCloseBrace(char c);
    int isDigSpaceDigCase (char eq[]);
    void removeSpaces(char source[], char dest[]);
    int matchingBraces(Stack s, char brace);
    int checkValidity( Equation eq);
    int readAndCheckEquations(char* fileName,Equality equality[]);
    int OperationPriority(char c);
    void intoPostfix (char original[], char postfix[]);
    int isInteger (float x);
    int pushResult (Stack s, char op);
    float evaluatePostfix (Equation postfix );
    void printValidEquations (char fileName [], Equality equality[] , int length);
    void printInvalidEquations (char fileName[] , Equality equality[] , int length);
    void printAllEquations (char fileName[] , Equality equality[] , int length);
    void printMenu (void);
    void printDescription (void);
    char getChoice(void);
    char* ExceptionMsg (int num);

    // main function
    int main(void){

        char EqFile[15], reportFile[15];   // variables for names of files.
        Equality equality[SIZE] ;
        int trial=0;

        printDescription();

        printf(">>> Please, Enter the name of the file where the equations are saved as follows (FileName.txt).\n  > ");
        scanf("%s", EqFile);

        int numOfLines= readAndCheckEquations(EqFile, equality);

        while (trial<3 && numOfLines==-1){
           printf("   Error in File Name or File does not exist!\n>>> Re-enter File Name > ");
           scanf("%s", EqFile);
           numOfLines= readAndCheckEquations(EqFile, equality);
           trial++;
        }

        if(trial==3){
            printf("\n   Sorry, you have exceeded the number of attempts allowed!\n");
            exit(0);
        }

        printMenu();
        char choice;
        printf("  Enter your choice  > ");
        choice = getChoice();
        while (choice!='4'){

            // scans the name of the file to print report in.
            if (choice == '1' || choice == '2' || choice == '3'){
                printf(">>> Enter the name of the File you want to print the report in as follows (ReportName.txt).\n  > ");
                scanf("%s", reportFile);
            }
            switch (choice){

               case '1' : printValidEquations(reportFile,equality, numOfLines);
                          printf("--> REPORT HAS BEEN SUCCESSFULLY PRINTED IN THE FILE. \n\n");
                          break;

               case '2' : printInvalidEquations(reportFile, equality, numOfLines);
                          printf("--> REPORT HAS BEEN SUCCESSFULLY PRINTED IN THE FILE. \n\n");
                          break;

               case '3' : printAllEquations(reportFile, equality, numOfLines);
                          printf("--> REPORT HAS BEEN SUCCESSFULLY PRINTED IN THE FILE. \n\n");
                          break;


               default : printf("    WRONG CHOICE!\n");
           }
            printf("    Enter your choice  > ");
            choice= getChoice();
        }

    printf("\n    THANK YOU :)\n");
    return 0;
    }


    // creates a Stack header and returns a pointer to it
    Stack createStack (void){
        Stack s= (Stack) malloc(sizeof(struct StackNode));
        s->next = NULL;
        return s;
    }

    // checks if the stack is empty
    int isEmpty(Stack s) {
        return (s->next==NULL);
    }

    // creates a new StackNode and adds it to specific stack.
    void push(Stack s, float c){
        position temp= (position) malloc(sizeof(struct StackNode));
        if (temp != NULL){
            temp->element= c;
            temp->next = s->next;
            s->next = temp;
        }
    }

    // removes the first Node from the given Stack.
    void pop(Stack s) {
        position temp ;
        if(!isEmpty(s)) {
            temp=s->next;
            s->next= temp->next;
            free(temp);
        }
    }

    // returns the first element in the given Stack.
    float top(Stack s) {
        if(!isEmpty(s))
            return s->next->element;
        return 0;
    }

    // returns if a given character is digit.
    int isDigit (char c){
        if (c>= '0' && c<= '9')
            return 1;
        return 0;
    }

    // returns if a given character is a mathematical Operation.
    int isOperation (char c){
        if (c=='+' || c=='-' || c== '*' || c== '/' || c=='%')
            return 1;
        return 0;
    }

    // returns if a given character is an open Brace.
    int isOpenBrace (char c){
        if (c=='(' ||  c== '[' || c=='{')
            return 1;
        return 0 ;
    }

    // returns if a given character is a close Brace.
    int isCloseBrace (char c){
        if (c==')' || c== ']' || c=='}')
            return 1;
        return 0 ;
    }

    // returns if a given character is a sign.
    int isSign(char c){
        if (c=='+' || c=='-')
            return 1;
        return 0;
    }

    // returns an integer indicates the type of a given character.
    int charType (char c){

        if (isDigit(c))
            return 1;
        else
            if (isOperation(c))
                return 2;
        else
            if (isOpenBrace(c))
                return 3;
        else
            if (isCloseBrace(c))
                return 4;
        else
            return -1;

    }

    // checks if the first character of the equation is valid
    int checkFirstChar (char c , char next){

        if (isDigit(c) || isOpenBrace(c))
            return 1;
        else if (isSign(c) && isDigit(next))   // allows the equation to start with sign
            return 1;
        return 0;

    }

    // checks if the last character of the equation is valid.
    int checkLastChar (char c){

        if (isDigit(c)|| isCloseBrace(c))
            return 1;
        return 0;
    }

    // checks if the character after a digit is valid.
    int checkAfterDigit (char c){

        if (isDigit(c) || isOperation(c) || isCloseBrace(c) || c=='\0')
            return 1;
        return 0;

    }

    // checks if the character after an operation is valid.
    int checkAfterOperation (char c){

        if (isDigit(c) || isOpenBrace(c) || isSign(c) )
                return 1;
        return 0;

    }

    // checks if the character after an open Brace is valid.
    int checkAfterOpenBrace (char c, char next){

        if (isDigit(c) || isOpenBrace(c))
            return 1;
        else if (isSign(c) && isDigit(next))
            return 1;

        return 0;

    }

    // checks if the character after a closing Brace is valid.
    int checkAfterCloseBrace (char c){

        if (isOperation(c) || isCloseBrace(c) || c== '\0')
            return 1;
        return 0;

    }


    /* checks the invalid case where there is two numbers seperated by spaces with no
    *operation between them. */

    int isDigSpaceDigCase (char* eq){
        int i=0;
        while (i<strlen(eq)){
            if (charType(eq[i])==1){
                if (eq[i+1]==' ') {
                        char *c = &eq[i+1];
                        while (*c == ' ')
                            c++;
                        if (isDigit(*c))
                             return 1;
                      }
            }
            i++;
        }
        return 0;
    }


    // removes the spaces from a given equation and saves the result in new Equation dest .
    void removeSpaces(char source[] ,  char dest[]){

        int i , j=0;
        for (i=0 ; i<strlen(source) ; i++){
            if (source[i]!= ' '){
                dest[j]= source[i];
                j++;
            }
        }

        dest[j]= '\0';
    }


    /* checks if the top of an open-braces Stack matches the corresponding closing brace.
     * and pops the stack if they are matched.*/

    int matchingBraces(Stack s, char brace){

        if (brace == ')' && top(s)==(int)'('){
            pop(s);
            return 1;
        }
        else
            if (brace == ']' && top(s)== (int) '['){
            pop(s);
            return 1;
        }
        else
            if (brace == '}' && top(s)== (int) '{'){
            pop(s);
            return 1;
            }

        return 0;
    }


    /** This function checks if an equation has a valid mathematical expression
    * @param Equation to be checked
    * @return 1 for valid, 0 for invalid
    */

    int checkValidity ( Equation eq){
        //We should check the case where two digits are seperated by spaces only before removing spaces.
        if (isDigSpaceDigCase(eq->originEq))
            return 0;

        int i=0;
        char newEq[SIZE];
        removeSpaces(eq->originEq, newEq);
        if (!(checkFirstChar(newEq[0], newEq[1])))    //checking first character.
            return 0 ;

        if (!(checkLastChar(newEq[strlen(newEq)-1]))) //checking last character.
            return 0;

        Stack Braces= createStack();  //Stack for checking the validity of braces.

        for (i=0; newEq[i]!= '\0' ; i++){

            int type = charType(newEq[i]);
            switch(type){

            // Digit
            case 1 :{ if (!(checkAfterDigit(newEq[i+1])))
                        return 0;
                    break;
            }

            //Operation
            case 2 :{   if (!(checkAfterOperation(newEq[i+1])))
                            return 0;

                        // No three concecutive operations
                        else if (isOperation(newEq[i+1]) && isOperation(newEq[i+2]))
                            return 0;

                        // No sign for Braces (e.g  7*-(5-4) )
                        else if (isOperation(newEq[i+1]) && isOpenBrace(newEq[i+2]))
                            return 0;

                    break;
            }

            // Open Brace
            case 3 : {  if (!(checkAfterOpenBrace(newEq[i+1], newEq[i+2])))
                            return 0;

                        else
                            push(Braces, (int)newEq[i]);
                    break ;
            }

            // Closing Brace
            case 4 : {  if (!(checkAfterCloseBrace(newEq[i+1])))
                            return 0;

                        //invalid if the stack is empty.
                        else if (isEmpty(Braces))
                            return 0;

                        //checks matching braces.
                        else if (!(matchingBraces(Braces, newEq[i])))
                            return 0;

                    break;
            }

            default : return 0;

            }
        }

        // makes sure that the stack of Braces is empty.
        if (!(isEmpty(Braces)))
            return 0;

        intoPostfix(newEq, eq->postFix);
        eq->result = evaluatePostfix(eq);
        return 1;

    }


    /** This function reads the equations from a file and creates an Equality
    * for each line, then checks the validity of equations in the equality.
    *@param fileName  the name of the file to read data from.
    *@param equality  array of pointers to Equalities to be filled with size [100].
    *@return 1 if the file exists, -1 if not.
    */

    int readAndCheckEquations(char fileName[] , Equality  equality[]){

        FILE* in = fopen (fileName, "r");
        if (in == NULL)
            return -1;

        else {

                int i=0,count=0, j;       // count: number of lines in the file
                char line[150];

                while (count < SIZE && fgets(line , 150, in)){
                    //skip empty lines
                    if (strcmp(line,"\n")==0)
                        continue;

                    //skip lines that contain only one equation
                    char temp[strlen(line)];
                    strcpy(temp, line);
                    char *dividor = strtok(line , "=");
                    if (strcmp(temp, dividor)==0)
                        continue;


                    j=0;
                    equality[i]= (Equality) malloc(sizeof(struct Equality));

                    while (j<2 && dividor!=NULL){

                        //removes the '\n' character from the end of dividor if exists
                        if (dividor[strlen(dividor)-1] == '\n')
                            dividor[strlen(dividor)-1]='\0';

                        equality[i]->Eq[j] = (Equation)malloc(sizeof(struct Equation));
                        equality[i]->Eq[j]->exception=0;

                        strcpy(equality[i]->Eq[j]->originEq , dividor);
                        equality[i]->Eq[j]->valid= checkValidity(equality[i]->Eq[j]);

                        j++;
                        dividor = strtok(NULL, "=");
                    }

                    count++;
                    i++;
                }

            return count;
        }
    }


    // returns the priority of operation.
    int OperationPriority(char c){

        if (isOpenBrace(c))
            return 0;

        else
            if (c=='+' || c=='-')
                return 1;

        else
            if (c=='*' || c=='/' || c=='%')
                return 2;

        return -1;
    }


    /** This function turns a valid equation into its POSTFIX Notation.
    *@param original   the equation to be convert.
    *@param postfix    the postfix of the equation.
    */

    void  intoPostfix (char infix[], char postfix[]){


        // creates Stack for the operations.
        Stack OpStack= createStack();


        int i=0 , j=0;

        // checks if the first character is a sign.
        if (isSign(infix[0]))
            postfix[j++]= infix[i++];

        while (i<strlen(infix)){

            char type = charType(infix[i]);
            switch(type){

                //Digit
                case 1: {
                    postfix[j++]= infix[i];
                    break;
                }

                //Operation
                case 2: {

                    postfix[j++]=',';
                    while (!(isEmpty(OpStack))  &&  OperationPriority((char)top(OpStack))>= OperationPriority(infix[i]) ){
                        postfix[j++]= (char)top(OpStack);
                        pop(OpStack);
                        postfix[j++]= ',';
                    }

                    push(OpStack, (int)infix[i]);

                    //checks if there is a sign after the operation.
                    if (isSign(infix[i+1]))
                        postfix[j++]= infix[++i];

                    break;
                }

                //Open Brace
                case 3: {

                    push(OpStack, (int)infix[i]);

                    //checks if there is a sign after the open brace.
                    if (isSign(infix[i+1]))
                        postfix[j++] = infix[++i];

                    break;
                }

                //Closing Brace
                case 4: {

                    while (!isOpenBrace((char)top(OpStack))){

                        postfix[j++] = ',';
                        postfix[j++] = (char)top(OpStack);
                        pop(OpStack);
                    }

                    pop(OpStack);
                    break;
                }

            }
            i++;

        }

        // pops all the contents of OpStack
        while (!isEmpty(OpStack)){
            postfix[j++]=',';
            postfix[j++]=(char) top(OpStack);
            pop(OpStack);

        }

        postfix[j]='\0';
    }


    //checks if a number is integer.
    int isInteger (float x){
        return x== (int)x;
    }


    /** This function executes an operation between the two top elements of the stack
    * and pushes the result into the stack.
    *@param Stack s : the source of operands and the destination of result.
    *@param op      : the operation to be executed.
    *@return 0 if there is no exceptions.
    */

    int pushResult (Stack s, char op){

        float res;
        int flag=0;    // indicator for exceptions

        float num2 = top(s);
        pop(s);
        float num1 = top(s);
        pop(s);

        switch (op){

            case '+': res = num1 + num2;
                      break;

            case '-': res = num1 - num2;
                      break;

            case '*': res = num1 * num2;
                      break;

            case '/' : {if (num2!=0 )
                            res= num1/num2;

                        else
                            flag=1;
                        break;
            }

            case '%' : { if (!(isInteger(num1)) || !(isInteger(num2)) || num2==0)
                            flag=2;
                        else
                            res= (int)num1%(int)num2;

            }
        }

        if (!flag)
            push(s, res);

        return flag;
    }


    /** This function evaluates the result of postfix expression .
    *@param FILE*  needed to print exceptions in the file.
    *@param postfix  the postfix expression of an equation.
    *@return result of postfix.
    */

    float evaluatePostfix ( Equation eq ){

        Stack NumStack = createStack();
        int i=0;

        while (i<strlen(eq->postFix)){

            char type = charType(eq->postFix[i]);
            switch (type){

                //Digit
                case 1 : {
                    int num=0, digit=0;
                    int count=0; // counts the number of digits in the number.

                    char possibleSign='\0';
                    if (i!=0)
                        possibleSign= eq->postFix[i-1];

                    // pointer to the most significant digit of the number.
                    char *c = &eq->postFix[i];

                    // moves the pointer c to the least significant digit.
                    while (eq->postFix[i]!= ',' && eq->postFix[i]!= '\0'){
                        count++;
                        c++;
                        i++;
                    }
                    c--;

                    while (count>0){
                        int x=(int) (*c - '0');
                        num= num + x*round((pow(10, digit)));
                        digit++;
                        c--;
                        count--;

                    }

                    if (possibleSign == '-')
                        num = -num;

                    push(NumStack, num);
                    break;
                    }

                // Operation
                case 2 : {

                    int flag;

                    // makes sure it is not a sign.
                    if (!isDigit(eq->postFix[i+1])){

                            flag = pushResult(NumStack,eq->postFix[i]);
                            if (flag==1) {
                                eq->exception =1;
                                return 0;
                            }
                            else if (flag ==2){
                               eq->exception =2;
                                return 0;

                            }
                    }
                }
            }
               i++;

        }

        return  top(NumStack);
    }


    /** This function prints the report of valid Equations. */
    void printValidEquations (char fileName[] , Equality equality [] , int length){

        FILE *report = fopen (fileName, "w");
        fprintf(report, "******  EQUALITIES WITH VALID EQUATIONS  ******\n\n");
        int i;
        for (i=0 ; i<length ; i++){

            if ((equality[i]->Eq[0]->valid) && (equality[i]->Eq[1]->valid)){

                fprintf(report, "    @ Line %d : \n", i+1);

                fprintf(report,"\t    [ %s = ", equality[i]->Eq[0]->postFix);

                if ((equality[i]->Eq[0]->exception)==0)
                    fprintf(report, "%.2f ] ",equality[i]->Eq[0]->result);
                else
                    fprintf(report, " %s ] " , ExceptionMsg(equality[i]->Eq[0]->exception));

                fprintf(report, " =? [ %s = " , equality[i]->Eq[1]->postFix );

                if ((equality[i]->Eq[1]->exception)==0)
                    fprintf(report, "%.2f ] ",equality[i]->Eq[1]->result);
                else
                    fprintf(report," %s ] ", ExceptionMsg(equality[i]->Eq[1]->exception));

                if (equality[i]->Eq[0]->result == equality[i]->Eq[1]->result)
                    fprintf(report, "  -->  True\n\n\n");
                else
                    fprintf(report, "  -->  False\n\n\n");
            }
        }

        fclose(report);

    }

    /** This function prints the report of invalid equations*/

    void printInvalidEquations (char fileName[] , Equality equality[] , int length){

        FILE*report= fopen (fileName, "w");
        fprintf(report, "\t\t****  EQUALITIES WITH ONE OR TWO INVALID EQUATIONS  ****\n\n");
        fprintf(report,"***********************************************************************************************\n");

        int i, j;
        for (i=0 ;i<length ; i++){

            if( !(equality[i]->Eq[0]->valid) || !(equality[i]->Eq[1]->valid)){
                fprintf(report, "\n@ Line %d : \n", i+1);

                for (j=0 ; j<2 ; j++){

                    fprintf(report, "\tEQUATION#%d  \n", j+1);
                    if ((equality[i]->Eq[j]->valid)){

                        fprintf(report, "\t    { %s } ->  VALID  ->  " ,equality[i]->Eq[j]->originEq);
                        if ((equality[i]->Eq[j]->exception)==0)
                            fprintf(report, "%.2f\n",equality[i]->Eq[j]->result);

                        else
                            fprintf(report, "[ %s ]\n" , ExceptionMsg(equality[i]->Eq[j]->exception));

                        fprintf(report, "\t    POSTFIX  ->> [ %s ]\n\n" , equality[i]->Eq[j]->postFix);

                    }

                    else
                        fprintf(report, "\t    { %s } ->  INVALID\n\n", equality[i]->Eq[j]->originEq);

                }
                fprintf(report,"***********************************************************************************************\n");
            }
         }
         fclose(report);
    }

    /** This function prints all the equations in a file and for each indicates the validity
    * if it is valid it prints the postfix notation and the result of it. */

    void printAllEquations (char fileName[] , Equality equality[] , int length){

        FILE *report= fopen (fileName, "w");

        fprintf(report , "***  ALL EQUALITIES  ***\n\n");
        int i,j;
        for (i=0 ; i<length ; i++){

            fprintf(report, "\n@ Line %d : \n", i+1);
            for (j=0 ; j<2 ; j++){

                fprintf(report, "\tEQUATION#%d  \n", j+1);
                if (equality[i]->Eq[j]->valid){

                    fprintf(report,"\t    %s   -->  VALID\n", equality[i]->Eq[j]->originEq);

                    fprintf(report,"\t    POSTFIX ->> [ %s ]\n", equality[i]->Eq[j]->postFix);

                    if ((equality[i]->Eq[j]->exception)==0)
                        fprintf(report,"\t    RESULT = %.2f\n\n", equality[i]->Eq[j]->result);
                    else
                        fprintf(report, "\t    [ %s ]\n\n", ExceptionMsg(equality[i]->Eq[j]->exception));


                }
                else
                    fprintf(report,"\t    %s   -->  INVALID\n\n", equality[i]->Eq[j]->originEq);

            }
        }

        fclose(report);
    }


    /** This function prints Menu Options to choose from */

    void printMenu (void){
        printf("\n----------------------------------------------------------------------------------------------\n");
        printf(">> OPTIONS MENU :\n\n");
        printf("   1. Print the equalities with two valid equations.\n\n");
        printf("   2. Print the equalities with one or two invalid equations.\n\n");
        printf("   3. Print all input equations,for each one state whether it is valid or not,\n"
               "      and if it is valid, print out the postfix format and the result.\n\n");
        printf("   4. Exit.\n\n");
        printf("----------------------------------------------------------------------------------------------\n\n  ");


    }


    /** This function prints the description of the program. */

    void printDescription (void){

        printf("                                 <<<<< WELCOME >>>>> \n\n");
        printf("****THE MAIN FUNCTIONALITIES OF THIS PROGRAM ARE :\n"
        "\n  - Reading a number of Equalities (Two Equations Seperated by '=') up to [100] from a FILE."
        "\n  - Checking if the format of each equation is valid."
        "\n  - Evaluating the POSTFIX notation and the result of each valid equation."
        "\n  - Printing many reports based on a specific choice.\n\n");
        printf("----------------------------------------------------------------------------------------------\n\n");

    }

    /* this function gets the choice of the user .*/
    char getChoice(void){
        char c = getchar();
        while (c=='\n' || c==' ')
            c = getchar();
        return c;

    }

    /* this function returns the messege of each exception.*/
    char* ExceptionMsg (int exception){
        char*messege = (char*) malloc(sizeof (char[SIZE]));
        if (exception== 1)
           strcpy (messege ,"Arithmetic Exception: Division By Zero.");
        else if (exception == 2)
            strcpy(messege, "Arithmetic Exception: Invalid Operand to Operation (%).");

        return messege;
    }
