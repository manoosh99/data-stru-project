#include <stdio.h>
#include <stdlib.h>


//For The Array which points to the array of characters
// to full data in cursor to radix sort
typedef int ptr;
typedef struct BucketNode{
  int Data;
  ptr next;

};

//For The Array of Characters

typedef struct NameNode {
  char character;
  ptr next;
};

typedef ptr list;
typedef ptr pos;
//For nameNode
#define BucketsNumber 100
int freelistBuckets=BucketsNumber-1;
typedef struct BucketNode Bcur; // define cursor from type bucket
Bcur Bucket_Cursor[BucketsNumber]; // header for cursor buckets

//For BucketNode
#define NamesSIZE 5000
int freelistNames=NamesSIZE-1;
typedef struct NameNode Ncur;
Ncur Names_Cursor[NamesSIZE];




/* function declaration */
void initializeBucketCURSOR();
void initializeNames_Cursor();
ptr BucketCursorAlloc();
ptr NamesCursorAlloc();
void InsertBucket(list L,pos p ,int x );
void InsertName(list L,pos p ,char x );
void BucketCursorFree(pos p);
void B_cursorFree(pos p);
void deleteBucket(list L,int x);
void B_deleteNode(list L,char x);
void PrintAllNames(FILE*myfile,list L);
int CompareListWithString (char s[50] , list L);
pos SearchName(list L , char s[50]);
void deleteName(list L , char name[50]);
int CompareListWithCharacter(list L , char c );
void PrintOneName(list L);
void SwapLists(list L1 , list L2);
int compareLists(list L1,list L2);
void RadixSort(list L);
void Tasks();
void print();

/*main*/


int main()
{
    char nameLine[50]; // define array to read max of line
    FILE *fptr; // read from file
    FILE *WriteFile; // write to others
    char cSearch;
    pos IfFound;
    initializeNamesCURSOR();
    initializeBucketCURSOR();

    int ch=0;
    char EOL='\n';
    Tasks();
    int task=0;
    list List_Name;
    pos Name_position;
    list Bucket=BucketCursorAlloc();
    pos Bucket_position=Bucket;
    //read names and put them in linked list
   fptr=fopen("Names.txt","r");
   if(fptr==NULL)
        printf("The File is Empty ! Error");
   else
        {

            fgets(nameLine,50,fptr);
            while(!feof(fptr))
                {

                    List_Name=NamesCursorAlloc(); // define list to put names we read from file
                    Name_position=List_Name;
                    for(ch=0;nameLine[ch]!=EOL;ch++)
                    {
                       InsertName(List_Name,Name_position,nameLine[ch]);
                       Name_position=Names_Cursor[Name_position].next;
                    }

                    InsertBucket(Bucket,Bucket_position,List_Name);
                    Bucket_position=Bucket_Cursor[Bucket_position].next;
                    fgets(nameLine,50,fptr);
                }


        }

        //Tasks cases

     printf("\n Write the task number you want : ");
     scanf("%d",&task);
     while(task!=6){

     if(task==1){

         //If the user choose to insert a new name

             printf("\n Write the name you want to insert : \n ");
             scanf("%s",nameLine);
             List_Name=NamesCursorAlloc(); //define new name want add to link
             Name_position=List_Name;
             //printf("%s",nameLine);
             for(ch=0;nameLine[ch]!='\0';ch++)
                {
                InsertName(List_Name,Name_position,nameLine[ch]);
                Name_position=Names_Cursor[Name_position].next;
                }
// first full one one char to linked list and later to buckets

             InsertBucket(Bucket,Bucket_position,List_Name);

             Bucket_position=Bucket_Cursor[Bucket_position].next;
     }
          // If the user choose to delete a Name

         else if (task==2){
             printf("\n Write a Name to delete : \n ");
             scanf("%s",nameLine);
             deleteName(Bucket,nameLine);

         }
         else if(task==3){

             //If the user choose to sort using Radix Sort .

             printf("\n Radix Sort ! \n Please exit the program before going to the output file !");

             RadixSort(Bucket);
             //After Sorting the results will appear in another file
             WriteFile=fopen("results.txt","w");
             PrintAllNames(WriteFile,Bucket);
         }

             // If the user want to search for a specific name .

         else if(task==4){

            printf("\n Write the name you want to search : \n");
            scanf("%s",nameLine);

            // The Function Search will be called and will give an int value

            IfFound= SearchName(Bucket,nameLine);

            //If the result is -1 then the name is not in the list

            if (IfFound==-1)
                {
                    printf("\nThe name is not found !! ");
                }
             //If the name is found then the function will return to the user the name position in List Buckets
           else
                {
                    printf("\nThe Name is Found ! It is at list %d\n",IfFound);
                }

         }



         else if(task==5){

            printf("\nWrite a character to find names which begin with it : \n ");
            scanf(" %c",&cSearch);

            SearchAllNames(Bucket,cSearch);

         }



         else{

            printf("\nYou have entered a wrong Number ! Please try again");
         }




     printf("\n Write the task number you want : ");
     scanf("%d",&task);

     }


   printf("\n End of the Program :) ");
   // print idea for all program
  /*int i=0;

    for ( i=0;i<=120;i++)
        printf("%d      %c      %d \n",i,Names_Cursor[i].character,Names_Cursor[i].next);

   for ( i=0;i<=10;i++)
     printf(" i=%d        Data= %d    Next= %d \n",i,Bucket_Cursor[i].Data,Bucket_Cursor[i].next);

*/
   return 0;
}

// Implementation of Bucket Cursor Array
void initializeBucketCURSOR(){
int i ;
for(i=0;i<BucketsNumber;++i){
    Bucket_Cursor[i].next=i+1;
}
    Bucket_Cursor[BucketsNumber-1].next=0;


}
ptr BucketCursorAlloc(){
pos p;
p=Bucket_Cursor[0].next;
Bucket_Cursor[0].next=Bucket_Cursor[p].next;
Bucket_Cursor[p].next=0;
--freelistBuckets;
return p ;
}

void InsertBucket(list L,pos p ,int x ){

pos temp=BucketCursorAlloc();
  if(temp){

    Bucket_Cursor[temp].Data=x;
    Bucket_Cursor[temp].next=Bucket_Cursor[p].next;
    Bucket_Cursor[p].next=temp;

  }

  if(Bucket_Cursor[temp].next==0)

    Bucket_Cursor[L].Data=temp;


}


void BucketCursorFree(pos p){

Bucket_Cursor[p].next=Bucket_Cursor[0].next;
Bucket_Cursor[0].next=p;
++freelistBuckets;

}

void deleteBucket(list L,int x){

 pos p,previous;

 p=Bucket_Cursor[L].next;
 previous=L;

  while ( p!=0 && Bucket_Cursor[p].Data!=x){

    previous=p;
    p=Bucket_Cursor[p].next;

  }

  if(p!=0){

    Bucket_Cursor[previous].next=Bucket_Cursor[p].next;

    BucketCursorFree(p);

  }

}

//Implementation for characters Cursor array
void initializeNamesCURSOR(){
int i ;
for(i=0;i<NamesSIZE;++i){
    Names_Cursor[i].next=i+1;
}
    Names_Cursor[NamesSIZE-1].next=0;


}

ptr NamesCursorAlloc()
{
pos p;
p=Names_Cursor[0].next;
Names_Cursor[0].next=Names_Cursor[p].next;
Names_Cursor[p].next=0;
--freelistNames;
return p ;
}

void InsertName(list L,pos p ,char x ){

pos temp=NamesCursorAlloc();
  if(temp){

    Names_Cursor[temp].character=x;
    Names_Cursor[temp].next=Names_Cursor[p].next;
    Names_Cursor[p].next=temp;

  }


  //if(Names_Cursor[temp].next==0)

    //Names_Cursor[L].character=temp;


}
void NamesCursorFree(pos p){

Names_Cursor[p].next=Names_Cursor[0].next;
Names_Cursor[0].next=p;
++freelistNames;

}
//This function print the menu to the user

void Tasks()
{
    printf(" **  Welcome to String Program  **  \n");
    printf("  You can choose one of the tasks below : \n");
    printf("(1).Insert a name\n");
    printf("(2).Delete a name\n");
    printf("(3).Sort name with Radix Sort\n");
    printf("(4).Search for  a name\n");
    printf("(5).Search list for all names that start with a specific character. \n");
    printf("(6).Exit the PROGRAM");


}

//Function to print One Name
//I will use it in another functions

void PrintOneName(list L){ //for  name list bl  name
pos position=Names_Cursor[L].next; // print next

while (position!=0){

    printf("%c",Names_Cursor[position].character); // print element
    position=Names_Cursor[position].next;
}


printf("\n");


}
// Print All List of Names to A File
//bucket list
void PrintAllNames(FILE*myfile,list L){
char s='\n';

pos Bucket_pos=Bucket_Cursor[L].next;
  while(Bucket_pos!=0)
    {


        pos Name_pos=Bucket_Cursor[Bucket_pos].Data;
        pos nameToPrint=Names_Cursor[Name_pos].next;

        while(nameToPrint!=0) // print name full for arrive end of it
            {

            fprintf(myfile,"%c",Names_Cursor[nameToPrint].character);

            nameToPrint=Names_Cursor[nameToPrint].next;
            }
            fprintf(myfile,"%c",s);

            Bucket_pos=Bucket_Cursor[Bucket_pos].next;
    }



}






//s search for name, list for bucket, take number and
int CompareListWithString (char s[50] , list L){
//If they are equal then the result = 1
int result=1;
int i =0 ;
pos Position = Names_Cursor[L].next;

while (s[i]!='\0'&&Position!=0&&result!=0){ // string for end

    if(s[i]!=Names_Cursor[Position].character)
         result=0;
    else
        {
        ++i;
        Position=Names_Cursor[Position].next;
        }
}
//compare the length


if(result==1)
    {

    if(s[i]=='\0'&& Position ==0)

     result=1; //same name but end is different

    else
    result=0;

    }


return result;
}
 // list bucket,
pos SearchName(list L , char s[50]){

//If the Name not Found the Found = 0
pos positionFound;
int Found =0;
pos position = Bucket_Cursor[L].next;
while (Found==0 && position!=0)
    {

    Found=CompareListWithString(s, Bucket_Cursor[position].Data);
    if(Found==0)
        {
            position=Bucket_Cursor[position].next;
        }

}

if(Found==1)

   positionFound= Bucket_Cursor[position].Data;

else

   positionFound=-1;


return positionFound;


}
//search name return position
void deleteName(list L , char name[50])
{

    int Found=SearchName(L , name);

    if (Found==-1)
        {

        printf("Not found the name to delete ");


        }

    else
        {
            deleteBucket(L,Found);
            printf ("The position we need to delete is %d", Found );
        }

}

// print all name for this char
int CompareListWithCharacter(list L , char c )
{

 //If they are equal then the result = 1
int result;

 pos FirstCharacter=Names_Cursor[L].next;
   if (Names_Cursor[FirstCharacter].character==c)

         result=1;

   else

        result=0;



return result;
}



void SearchAllNames(list L , char c)

{

int Found;

pos Position = Bucket_Cursor[L].next;

while (Position!=0)

    {

       Found=CompareListWithCharacter(Bucket_Cursor[Position].Data , c );
       if(Found==1)
        {
          PrintOneName(Bucket_Cursor[Position].Data);
          Position=Bucket_Cursor[Position].next;
        }

        else
            Position=Bucket_Cursor[Position].next;
     }




}


void SwapLists(list L1 , list L2)
{
    //we want to swap two lists of names to help us with Radix Sort

    ptr temp;
    temp=Bucket_Cursor[L1].Data;
    Bucket_Cursor[L1].Data=Bucket_Cursor[L2].Data;
    Bucket_Cursor[L2].Data=temp;

}

int compareLists(list L1,list L2){
int result=1;
int Finish=0;
ptr c1=Names_Cursor[L1].next;
ptr c2=Names_Cursor[L2].next;

while (Finish==0 && c1!=0 && c2!=0) // end of list
    {

    if (Names_Cursor[c1].character>Names_Cursor[c2].character)
        {

            result=2;
            Finish=1;
        }

    else if(Names_Cursor[c1].character<Names_Cursor[c2].character)
        {

            Finish=1; // stay as you enter

        }
     // equal check next char
     else
        {
            c1=Names_Cursor[c1].next;
            c2=Names_Cursor[c2].next;
        }

    }

//We Want to check the length of the lists even if the results equal
 if (Finish==0 && c2==0 && c1!=0)
 {

    result=2;
 }

 return result;

}
// sort element found it in cursor
void RadixSort(list L){
pos position;
int r;
pos current_Position=Bucket_Cursor[L].next;
while (current_Position!=0){

    position=Bucket_Cursor[current_Position].next;

    while(position!=0){

            r=compareLists(Bucket_Cursor[current_Position].Data,Bucket_Cursor[position].Data);
            if (r==2){ // large

                SwapLists(current_Position,position);
            }


        position=Bucket_Cursor[position].next;


    }

    current_Position=Bucket_Cursor[current_Position].next;
}

}














