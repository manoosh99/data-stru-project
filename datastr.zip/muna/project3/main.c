#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


// Constants for AVL Tree Rotation Types
#define SRRL_T 1  //single rotation
#define SRLR_T -1
#define DRRL_T 2
#define DRLR_T -2  //double rotation left

// Constants for status in hash table record
#define EMPTY 0
#define INSERT 1
#define DELETE 2


typedef struct node* AVL;

struct node{

    char city[21];
    char file[100];
    AVL left;
    AVL right;
    int height;
};


typedef struct record Record;

struct record{
    int ID;
    char name[50];
    int age;
    char gender;
    int status;
};

typedef struct hashTable HT;

struct hashTable{
    int size;
    int numOfRecords;
    Record *records;
};

// AVL Tree Functions

AVL findCity (AVL, char *);
AVL findMin (AVL);

AVL insertToTree (AVL T, char *, char *);
AVL deleteFromTree (AVL, char *);
void deleteAllTree(AVL);

int getHeight (AVL);
int max (int, int);
void updateHeight (AVL);

AVL SRLR (AVL);
AVL SRRL (AVL);
AVL DRLR (AVL);
AVL DRRL (AVL);

void printTreeToFileInOrder (AVL, char *);
void printTreeInOrder (AVL);
void printTreePreOrder (AVL);
void printTreePostOrder (AVL);

int isBalanced (AVL);
int rotationType (AVL);
AVL rotate (AVL, int);

AVL readTreeFromFile (AVL);
void writeTreeToFile (AVL);


// Hashing Table Functions

int requiredTableSize(int);
int isPrime(int);

int hashFunction(HT, int);
int quadraticHashing(HT, int);
void rehash(HT *);

void insertToTable(HT *, Record);
void deleteFromTable(HT, int);
int findRecord(HT, int); // find sjael

void readTableFromFile(HT *, AVL);
void writeTableToFile (HT);

void printTable(HT);
void printTableSize(HT);
void printHashFunction(HT);

// Menu Diplay Functions

void treePrintingChoices(AVL);
void heightPrintingChoices(AVL);

int main()
{
    AVL T = NULL;                   // initializing the tree with NULL
    HT table = {0, 0, NULL};        // initializing the table with nulls

    int hashTableLoaded = 0;            // this will remain zero until data loaded to the hash table

    int option;

    do{
        printf("    \t\t\t\t\t\t     Main Menu\n\n");                   // displaying the menu
        printf("\t\t\t\t\t   1)Read counties data from file\n");
        printf("\t\t\t\t\t   2)Print counties data\n");
        printf("\t\t\t\t\t   3)Search for county\n");
        printf("\t\t\t\t\t   4)Insert a new county\n");
        printf("\t\t\t\t\t   5)Delete a county\n");
        printf("\t\t\t\t\t   6)Get height\n");
        printf("\t\t\t\t\t   7)Write counties data to file\n");
        printf("\t\t\t\t\t   8)Load county's data from file\n");
        printf("\t\t\t\t\t   9)Print table size\n");
        printf("\t\t\t\t\t  10)Print used hash function\n");
        printf("\t\t\t\t\t  11)Display hash table on the screen\n");
        printf("\t\t\t\t\t  12)Insert a new record to the hash table\n");
        printf("\t\t\t\t\t  13)Delete a record from the hash table\n");
        printf("\t\t\t\t\t  14)Search for a specific record in the hash table\n");
        printf("\t\t\t\t\t  15)Write county's data to file\n");
        printf("\t\t\t\t\t  16)Exit\n");

        printf("\n\n\t\t\t\t\t  Enter you choice please: ");

        scanf("%d",&option);            // getting the user's choice

        switch (option){

        char county[21];
        char countyFile[100];

        case 1:
            system("cls");          // clear screen
            T = readTreeFromFile(T);        // reading data from file and saving it in tree T
            printf("\n\nPress any key to return to main menu\n");
            getch();
            system("cls");          // clear screen
            break;

        case 2:
            system("cls");          // clear screen
            treePrintingChoices(T); // displaying tree printing choices menu
            system("cls");          // clear screen
            break;

        case 3:
            system("cls");          // clear screen
            printf("Enter the county that you want to look for please:\n");

            fflush(stdin);      // flushing the stdin from any previous '\n'
            gets(county);       // getting the county's name from user

            AVL key = findCity(T, county);      // finding this county's node in the tree

            printf("\n");       // new line

            if (key == NULL)        // if the key == NULL, then county does not exist, so show an error message
                printf("county \"%s\" is not found\n", county);
            else                    // if exist, print its data
                printf("county \"%s\" is found and its file name is \"%s\"\n",key -> city, key -> file);

            printf("\n\nPress any key to return to main menu\n");       // returning to main menu
            getch();

            system("cls");          // clear screen
            break;

        case 4:
            system("cls");          // clear screen

            printf("Enter the county that you want to insert please:\n");

            fflush(stdin);          // flushing the stdin from any previous '\n'
            gets(county);           // getting county from user

            printf("\nEnter the county's file name please:\n");

            gets(countyFile);       // getting county's file name from user

            T = insertToTree(T, county, countyFile);        // inserting county's data to the tree

            printf("\nCounty has inserted successfully\n");

            printf("\n\nPress any key to return to main menu\n");   // returning to main menu
            getch();

            system("cls");          // clear screen
            break;

        case 5:
            system("cls");          // clear screen

            if (T != NULL){         // if the tree is not empty
                printf("Enter the county that you want to delete please:\n");

                fflush(stdin);   // flushing the stdin from any previous '\n'
                gets(county);           // getting county from user

                T = deleteFromTree(T, county);      // deleting the node

                printf("\nCounty has deleted successfully\n");
            }
            else                    // if county does not exist, show an error message
                printf("No counties to delete!");

            printf("\n\nPress any key to return to main menu\n");       // returning to main menu
            getch();

            system("cls");          // clear screen
            break;

        case 6:
            system("cls");          // clear screen

            if (T != NULL)          // if the tree is not empty
                heightPrintingChoices(T);   // display height printing choices menu
            else                    // if tree is empty, show an error message
                printf("No counties in the tree!");

            system("cls");          // clear screen
            break;

        case 7:
            system("cls");          // clear screen

            if (T != NULL)
                writeTreeToFile(T);
            else
                printf("No counties to delete!");

            printf("\n\nPress any key to return to main menu\n");
            getch();
            system("cls");      // clear screen
            break;

        case 8:
            system("cls");      // clear screen

            if (T != NULL){         // if the tree is not empty
                printf("Counties:\n\n");
                printTreeInOrder(T);        // print tree in-order
                printf("\n");

                table.size = 0;             // reset hash table to load new data
                table.numOfRecords = 0;
                free(table.records);        // deleting the old records table
                table.records = NULL;

                readTableFromFile(&table, T);       // reading the data from file and saving it to the hash table

                hashTableLoaded = 1;            // this means that the data has loaded to the hash table
            }
            else                    // if tree is empty, show an error message
                printf("No counties in the tree!");

            printf("\n\nPress any key to return to main menu\n");       // returning to main menu
            getch();
            system("cls");

            break;

        case 9:
            system("cls");          // clear screen

            if (hashTableLoaded)    // if data has read from file and the hash table has loaded
                printTableSize(table);      // print table size
            else                    // if data has not read from file or the hash table has not loaded yet, then show an error message
                printf("No data loaded to the hash table!");

            printf("\n\nPress any key to return to main menu\n");   // returning to main menu
            getch();
            system("cls");          // clear screen
            break;


        case 10:
            system("cls");          // clear screen

            if (hashTableLoaded)            // if data has read from file and the hash table has loaded
                printHashFunction(table);       // printing the hash function
            else                             // if data has not read from file or the hash table has not loaded yet, then show an error message
                printf("No data loaded to the hash table!");

            printf("\n\nPress any key to return to main menu\n");       // returning to main menu
            getch();
            system("cls");          // clear screen
            break;


        case 11:
            system("cls");          // clear screen

            if (hashTableLoaded)        // if data has read from file and the hash table has loaded
                printTable(table);      // printing the hash table on the screen
            else                        // if data has not read from file or the hash table has not loaded yet, then show an error message
                printf("No data loaded to the hash table!");

            printf("\n\nPress any key to return to main menu\n");       // returning to main menu
            getch();
            system("cls");          // clear screen
            break;


        case 12:
            system("cls");          // clear screen

            if (hashTableLoaded){   // if data has read from file and the hash table has loaded

                Record record;      // creating a record to save the data in, and to insert it to the hash table

                printf("Enter the ID please:\n");
                scanf("%d",&record.ID);             // getting the record's ID from user

                printf("Enter the full name please:\n");
                fflush(stdin);                      // flushing the stdin from any previous '\n'
                gets(record.name);                  // getting the record's name from user

                printf("Enter the age please:\n");
                scanf("%d",&record.age);            // getting the record's age from user

                printf("Enter the gender please (m/f):\n");
                scanf(" %c",&record.gender);        // getting the record's gender from user

                insertToTable(&table, record);      // inserting the record to the hash table

                printf("\n\nRecord inserted successfully\n");
            }
            else                        // if data has not read from file or the hash table has not loaded yet, then show an error message
                printf("No data loaded to the hash table!");

            printf("\n\nPress any key to return to main menu\n");       // returning to main menu
            getch();
            system("cls");          // clear screen
            break;


        case 13:
            system("cls");      // clear screen

            if (hashTableLoaded){   // if data has read from file and the hash table has loaded
                int ID;

                printf("Enter the ID for the record that you want to delete please:\n");
                scanf("%d",&ID);                // getting the ID from user

                deleteFromTable(table, ID);     // deleting the record that has that ID

                printf("\n\nRecord deleted successfully\n");
            }
            else                    // if data has not read from file or the hash table has not loaded yet, then show an error message
                printf("No data loaded to the hash table!");

            printf("\n\nPress any key to return to main menu\n");       // returning to main menu
            getch();
            system("cls");      // clear screen
            break;


        case 14:
            system("cls");      // clear screen

            if (hashTableLoaded){       // if data has read from file and the hash table has loaded
                int ID;

                printf("Enter the ID for the record that you want to look for please:\n");
                scanf("%d",&ID);        // getting the ID from user

                int key = findRecord(table, ID);        // searching for the record in the hash table

                if (key != -1){         // if exist, print its data

                    printf("\n\nRecord has been found:\n\n");
                    printf("ID = %d\n",table.records[key].ID);      // printing record's data
                    printf("name = %s\n",table.records[key].name);
                    printf("age = %d\n",table.records[key].age);
                    printf("gender = %c\n",table.records[key].gender);
                }
                else                    // if the record is not found, show an error message
                    printf("No such record!");
            }
            else                        // if data has not read from file or the hash table has not loaded yet, then show an error message
                printf("No data loaded to the hash table!");

            printf("\n\nPress any key to return to main menu\n");       // returning to main menu
            getch();
            system("cls");      // clear screen
            break;

        case 15:
            system("cls");      // clear screen

            if (hashTableLoaded)            // if data has read from file and the hash table has loaded
                writeTableToFile(table);    // writing hash table data to file
            else                            // if data has not read from file or the hash table has not loaded yet, then show an error message
                printf("No data loaded to the hash table!");

            printf("\n\nPress any key to return to main menu\n");       // returning to main menu
            getch();
            system("cls");      // clear screen
            break;

        case 16:                // exit
            system("cls");      // clear screen
            break;

        default:                // if any other option has chosen, show an error message
            system("cls");      // clear screen
            printf("\t\t\t\t No such option! Enter your choice again please:\n\n");
        }

    }while (option != 16);


    free(table.records);         // deleting the hash table
    deleteAllTree(T);            // deleting all the nodes in the tree

    return 0;
}


AVL findCity (AVL T, char *city){       // this function is to search the tree by the city name as the key

    if (T == NULL)                      // if the tree has no nodes return NULL
        return NULL;

    while ( T != NULL  &&  strcmp(T -> city, city) != 0 ){  // keep searching until you find the wanted node or NULL

        if (strcmp(city, T -> city) < 0)       // if key < the node we are standing at go left
            T = T -> left;
        else                                   // if key > the node we are standing at go right
            T = T -> right;
    }

    return T;                   // after ending the loop return T ( T may be the founded node or NULL if not found)
}

AVL findMin (AVL T){            // this function is to find the minimum value in the tree (the key is city name here)

    if (T == NULL)              // if the tree has no nodes return NULL
        return NULL;

    while (T -> left != NULL)   // if T has a left then keep going left until you reach the far left (the minimum)
        T = T -> left;

    return T;
}

AVL insertToTree (AVL T, char *city, char *file){     // this function will insert a node with given data to the tree

    if (T == NULL){                                   // if this subtree has no nodes create one
        T = (AVL) malloc (sizeof(struct node));

        if (T != NULL){                               // if the node has created successfully, then save the given data in
            strcpy (T -> city, city);
            strcpy (T -> file, file);
            T -> height = 0;                          // set its height to zero, since we add to the leaves
            T -> left = T -> right = NULL;
        }
        else{                                         // if no enough memory print an error message and exit
            printf("Error! Out of Memory!\n");
            exit(0);
        }
    }

    else if (strcmp(city, T -> city) < 0)                   // if the value we want to insert is less than the node we are standing at, go left
        T -> left = insertToTree(T -> left, city, file);
    else                                                    // if the value we want to insert is larger than the node we are standing at, go right
        T -> right = insertToTree(T -> right, city, file);

    updateHeight(T);        // update the height after inserting the node

    if (!isBalanced(T))                     // if the tree is not balanced, make a rotation
        return rotate(T, rotationType(T));

    return T;
}

AVL deleteFromTree (AVL T, char *city){                 // this function is to delete a node from the tree

    if (T == NULL)                              // if the tree has no nodes to delete, return NULL
        return NULL;

    if (strcmp(city, T -> city) < 0)                    // if the value we want to delete is less than the node we are standing at, go left
        T -> left = deleteFromTree(T -> left, city);

    else if (strcmp(city, T -> city) > 0)               // if the value we want to delete is less than the node we are standing at, go right
        T -> right = deleteFromTree(T -> right, city);

    else if (T -> left && T -> right){                  // if we reached the node that we want and it has two children
        AVL min = findMin(T -> right);                  // find the minimum in the right subtree
        strcpy(T -> city, min -> city);                 // move the data in min to the node we want to delete
        strcpy(T -> file, min -> file);
        T -> right = deleteFromTree(T -> right, min -> city);   // delete min from the tree
    }
    else{                   // if we reached the node that we want and it has one or zero children
        AVL child;

        if (T -> left == NULL)      // if the left is NULL, then the child is the right one (even if it is also NULL)
            child = T -> right;

        else if (T -> right == NULL)    // if the right is NULL, then the child is the left one (even if it is also NULL)
            child = T -> left;

        free(T);          // delete the node and return child to connect it with the tree

        return child;
    }

    updateHeight(T);        // update the height after deleting a node

    if (!isBalanced(T))                        // if the tree is not balanced, make a rotation
        return rotate(T, rotationType(T));

    return T;
}

void deleteAllTree(AVL T){          // this function is to delete all nodes in the tree

    if (T != NULL){

        if (T -> left)              // if T has a left subtree
            deleteAllTree(T -> left);       // delete the left subtree

        if (T -> right)             // if T has a right subtree
            deleteAllTree(T -> right);      // delete the right subtree

        free(T);                // delete the root
    }
}

int getHeight (AVL T){              // this function is to return the height of the given subtree

    if (T == NULL)                  // if it is NULL return height = -1
        return -1;
    else                            // else return its height
        return T -> height;
}

int max (int x, int y){         // this function is to find the maximum of two numbers

    if (x >= y)                 // if the first >= the second one, then its is the maximum
        return x;
    else                        // if the first < the second one, then the second is the maximum
        return y;
}

void updateHeight (AVL T){              // this function is to update the height of each subtree after inserting or deleting a node

    T -> height = 1 + max (getHeight(T -> left), getHeight(T -> right));        // the height is the maximum height of the both children + 1
}

AVL SRLR (AVL k2){              // single rotate left to right

    AVL k1 = k2 -> left;
    k2 -> left = k1 -> right;       // let the left of k2 = the right of k1
    k1 -> right = k2;               // let the right of k1 = k2

    updateHeight(k2);               // update the height of k2
    updateHeight(k1);               // update the height of k1

    return k1;
}

AVL SRRL (AVL k1){              // single rotate right to left

    AVL k2 = k1 -> right;

    k1 -> right = k2 -> left;   // let the right of k1 = the left of k2
    k2 -> left = k1;            // let the left of k2 = k1

    updateHeight(k1);           // update the height of k1
    updateHeight(k2);           // update the height of k2

    return k2;
}

AVL DRLR (AVL k3){              // double rotate left to right

    k3 -> left = SRRL(k3 -> left);      // make a single rotate right to left on k2 (the left of k3)
    return SRLR(k3);                    // make a single rotate left to right on k3
}

AVL DRRL (AVL k1){              // double rotate right to left

    k1 -> right = SRLR(k1 -> right);    // make a single rotate left to right on k2 (the right of k1)
    return SRRL(k1);                    // make a single rotate right to left on k1
}

void printTreeToFileInOrder (AVL T, char *out){     // this function is to print the tree nodes to a file inOrder

    if (T != NULL){                                     // if NULL print nothing
        printTreeToFileInOrder(T -> left, out);         // print left subtree
        fprintf(out,"%s   %s\n",T -> city, T -> file);  // print the root
        printTreeToFileInOrder(T -> right, out);        // print right subtree
    }
}

void printTreeInOrder (AVL T){

    if (T != NULL){                                // if NULL print nothing
        printTreeInOrder(T -> left);               // print left subtree
        printf("%s   %s\n",T -> city, T -> file);  // print the root
        printTreeInOrder(T -> right);              // print right subtree
    }
}

void printTreePreOrder (AVL T){

    if (T != NULL){                                // if NULL print nothing
        printf("%s   %s\n",T -> city, T -> file);  // print the root
        printTreePreOrder(T -> left);              // print left subtree
        printTreePreOrder(T -> right);             // print right subtree
    }
}

void printTreePostOrder (AVL T){

    if (T != NULL){                                 // if NULL print nothing
        printTreePostOrder(T -> left);              // print left subtree
        printTreePostOrder(T -> right);             // print right subtree
        printf("%s   %s\n",T -> city, T -> file);   // print the root
    }
}

int isBalanced (AVL T){         // this function will check the balance of the given tree

    if ( abs( getHeight(T -> left) - getHeight(T -> right) ) < 2 )      // using the rule if | height(left) - height(right)| < 2  then it is balanced
        return 1;
    else                                                                // otherwise it is not
        return 0;
}

int rotationType (AVL T){               // this function will determine the needed rotation for the given tree and return the type as integer

    if ( getHeight(T -> left) < getHeight(T -> right) ){        // if the tree is right heavy

        if ( getHeight(T -> right -> left) >= getHeight(T -> right -> right) )      // if the tree's right subtree is left heavy
            return DRRL_T;                                                          // perform a double rotation right to left
        else                                                                        // if the tree's right subtree is right heavy
            return SRRL_T;                                                          // perform a single rotation right to left
    }

    if ( getHeight(T -> left) > getHeight(T -> right) ){        // if the tree is left heavy

        if ( getHeight(T -> left -> left) <= getHeight(T -> left -> right) )        // if the tree's left subtree is right heavy
            return DRLR_T;                                                          // perform a double rotation left to right
        else                                                                        // if the tree's left subtree is left heavy
            return SRLR_T;                                                          // perform a single rotation left to right
    }
}

AVL rotate (AVL T, int rotationType){                   // this function will make a rotation on T depending on the given type

    switch (rotationType){
        case SRRL_T: return SRRL(T);                    // if the wanted type is SRRL then do it
        case SRLR_T: return SRLR(T);                    // if the wanted type is SRLR then do it
        case DRRL_T: return DRRL(T);                    // if the wanted type is DRRL then do it
        case DRLR_T: return DRLR(T);                    // if the wanted type is DRLR then do it
    }
}

AVL readTreeFromFile (AVL T){                   // this function will read data from file and insert it to the given tree

    char path[100];

    printf("Enter the file path please:\n");

    fflush(stdin);      // flushing the stdin from any previous '\n'
    gets(path);         // getting the path from user

    FILE *in = fopen(path, "r");    // open the file for reading

    while (in == NULL){         // if the file path is wrong or file is not found , request the path again
        system("cls");                          // clear screen
        printf("Error! File not Found!\n\n");
        printf("Please enter the file path again:\n");

        gets(path);             // retry
        in = fopen(path,"r");
    }

    char line[123];

    while (fgets(line,123,in) != NULL){                 // keep reading lines until reaching NULL (end of file)

        char *token = strtok(line,"/\n");                  // split the line to 2 pieces of data depending on '/' (or '\n' for end of line)
        T = insertToTree(T, token, strtok(NULL,"/\n"));    // insert it to the tree
    }

    fclose(in);         // close the file

    return T;
}

void writeTreeToFile (AVL T){       // this function will write data in the given tree to the file

    char path[100];

    printf("Enter the file path please:\n");

    fflush(stdin);                  // flushing the stdin from any previous '\n'
    gets(path);                     // getting the path from user

    FILE *out = fopen(path, "w");   // open the file for writing

    while (out == NULL){            // if the given path is incorrect, request the path again
        system("cls");
        printf("Error! Cannot create this file!\n\n");
        printf("Please enter the file path again:\n");

        gets(path);                 // retry
        out = fopen(path,"w");
    }

    printTreeToFileInOrder(T, out);     // print the data to file inOrder

    fclose(out);
}


int requiredTableSize(int n){           // this function will return the required table size for the given n size of data (which is first prime > 2n)

    int requiredTableSize = 2*n + 1;    // starting from first number after 2n

    while(!isPrime(requiredTableSize))  // finding the first prime after 2n
        requiredTableSize++;

    return requiredTableSize;
}

int isPrime(int num){           // this function will check if the given number is prime or not

    int i;

    for(i = 2 ; i <= num/2 ; i++)   // for i = 2 to num/2 if i divides num then num is not prime
        if (num % i == 0)
            return 0;

    return 1;                       // if the loop ended with no i divides num, then num is prime
}

int hashFunction(HT table, int ID){     // hashing function

    return ID % table.size;             // ID mod table size
}

int quadraticHashing(HT table, int ID){     // quadratic probing function

    int i = 1;

    int index = hashFunction(table, ID);    // find the suitable index for the given ID
    int quadIndex = index;

    while(table.records[quadIndex].status == INSERT){   // if that index is busy, keep searching for another quadratically

        quadIndex = (index + i*i) % table.size;         // searching for another index quadratically ( f(x) = (h(x) + i*i) % table size )
        i++;
    }

    return quadIndex;
}

void rehash(HT *table){             // rehashing function

    int oldTableSize = (*table).size;                       // save the old table size in this variable
    int newTableSize = requiredTableSize(oldTableSize);     // find the new required table size
    (*table).size = newTableSize;                           // change the table size to the new required one

    Record *temp = (*table).records;                        // saving the records in a temporary storage
    (*table).records = (Record *) calloc(newTableSize, sizeof(Record) );   // creating new record list with the new table size

    int i;

    for (i = 0 ; i < oldTableSize ; i++)        // re-inserting the values in the old hash table to the new one
        if( temp[i].status == INSERT)
            insertToTable(table, temp[i]);

    free(temp);                                 // deleting the old hash table
}

void insertToTable(HT *table, Record record){   // this function is to insert a new record to the hash table

    (*table).numOfRecords++;                    // increment the number of records by 1

    if ( (*table).size < requiredTableSize( (*table).numOfRecords ) )   // if the current table size is less than the required one, rehash the table
        rehash(table);

    record.status = INSERT;                     // set the added record's status to "INSERT" status

    int index = quadraticHashing(*table, record.ID);        // find a suitable position for the new record

    (*table).records[index] = record;                       // insert the new record to the suitable position
}

void deleteFromTable(HT table, int ID){    // this function is to delete a record from the hash table (ID is the key here)

    int index = findRecord(table, ID);     // find the position of the record that we want to delete

    if (index != -1)                            // if found, delete it by setting its status to "DELETE" status
        table.records[index].status = DELETE;
}

int findRecord(HT table, int ID){               // this function is to search the table for a record (the ID is the key)

    int i = 1;

    int index = hashFunction(table, ID);        // find the position of the record
    int quadIndex = index;

        while(table.records[quadIndex].status != EMPTY){                   /* if the position founded previously does not contain the target
                                                                           then keep searching for it quadratically */

        if (table.records[quadIndex].status != DELETE && table.records[quadIndex].ID == ID)   // if found, return its index
            return quadIndex;

        else{                                                       // if now found, keep searching until finding it or reaching the end of the hash table
            quadIndex = (index + i*i) % table.size;
            i++;
        }
    }

    return -1;          // if this statement reached, then the record is not found, so return -1
}

void readTableFromFile(HT *table, AVL T){       // this function will read data from file and insert it into the given hash table

    char county[21];

    printf("Enter the county that you want to load its data please:\n");

    fflush(stdin);        // flushing the stdin from any previous '\n'
    gets(county);           // getting the county from user

    AVL key = findCity(T, county);          // search for the county's file in the tree

    FILE *in;

    if (key == NULL){                    // if not county found show an error message
        printf("No such county!\n");
        return;
    }
    else                                // if found open the file
        in = fopen(key -> file, "r");   // opening the file for reading

    if(in == NULL){                     // if file can't be open, show an error message
        system("cls");                  // clear screen
        printf("Error! Data file for this county is not Found!\n\n");
        return;
    }

    char line[65];
    int numberOfLines = 0;

    while (fgets(line,65,in) != NULL)       // counting the number of lines (size of data) in the file
        numberOfLines++;

    (*table).size = requiredTableSize(numberOfLines);                       // setting the table size to the required size for this data
    (*table).records = (Record *) calloc( (*table).size , sizeof(Record) ); // creating a record list with null values

    rewind(in);                             // returning the file pointer to the beginning of the file

    while (fgets(line,65,in) != NULL){      // reading data from file line by line until reaching NULL (end of file)

        char *strID = strtok(line,"/");       // cutting the first value (ID) depending on '/'
        char *strName = strtok(NULL,"/");     // cutting the second value (name) depending on '/'
        char *strAge = strtok(NULL,"/");      // cutting the third value (age) depending on '/'
        char *strGender = strtok(NULL,"/\n");   // cutting the fourth value (gender) depending on '/' (or '\n' for end of line)

        Record record;         // creating a record to save the data in

        record.ID = atoi(strID);        // convert the string value to integer value and save it in record.ID
        strcpy(record.name, strName);   // save the name in record.name
        record.age = atoi(strAge);      // convert the string value to integer value and save it in record.age
        record.gender = strGender[0];   // save the first char in the string (which contains only one char) in record.gender

        insertToTable(table, record);   // insert the read record to the hash table
    }

    printf("\nData loaded successfully\n");

    fclose(in);         // close the file
}

void writeTableToFile (HT table){       // this function will write the data in the table to the file (without spaces)

    char path[100];

    printf("Enter the file path please:\n");

    fflush(stdin);      // flushing the stdin from any previous '\n'
    gets(path);         // getting the path from the user

    FILE *out = fopen(path, "w");       // opening the file for writing

    while (out == NULL){                // if the given path is incorrect, request the path again
        system("cls");          // clear screen
        printf("Error! Cannot create this file!\n\n");
        printf("Please enter the file path again:\n");

        gets(path);                 // retry
        out = fopen(path,"w");
    }

    int i;

    for(i = 0 ; i < table.size ; i++)           // printing the table to the file
        if(table.records[i].status == INSERT)   // without the spaces or the deleted values
            fprintf(out, "%d/%s/%d/%c\n", table.records[i].ID,table.records[i].name, table.records[i].age, table.records[i].gender);

    fclose(out);
}

void printTable(HT table){          // this function will display the table on the screen (including empty spots)

    int i;

    printf("note: the data will be showed in the following form:\n");
    printf("index/ID/Name/Age/Gender/Entry Status\n\n\n");

    for(i = 0 ; i < table.size ; i++) // printing all the data in the table
        if (table.records[i].status != EMPTY)
            printf("(index = %d):  %d / %s / %d / %c  (status = %d)\n",i, table.records[i].ID,table.records[i].name, table.records[i].age, table.records[i].gender, table.records[i].status);
        else
            printf("(index = %d):\n", i);
}

void printTableSize(HT table){                  // this function will display the table size on the screen

    printf("table size is %d\n",table.size);
}

void printHashFunction(HT table){               // this function will display the hash function used on the screen

    printf("function used for hashing:\n");
    printf("h(x) = x %% %d\n\n",table.size);      // "%%" has used to display one '%'

    printf("function used for quadratic probing:\n");
    printf("f(x) = (h(x) + i*i) %% %d = (x %% %d + i*i) %% %d\n",table.size, table.size, table.size);      // function used for quadratic probing
}


void treePrintingChoices(AVL T){                // this function is to display the printing choices for the tree to the user

    char option;

    do{
        printf("1)Print tree pre-order\n");         // options
        printf("2)Print tree in-order\n");
        printf("3)Print tree post-order\n");
        printf("4)Return to main menu\n");

        option = getch();               // getting the user option

        if (T == NULL && option != '4'){        /* if the tree is empty and the user tried to print it show error message
                                                (but don't show the error message if he wanted to exit)*/
            system("cls");      //clear screen
            printf("No data to print!\n\n");
            printf("press any key to return to previous menu\n");
            getch();
            continue;             // continue used here to prevent continuing below
        }

        switch (option){

        case '1':
            system("cls");       // clear screen
            printTreePreOrder(T);       // printing the tree to the screen pre-order
            printf("\n\nPress any key to return to previous menu\n");
            getch();
            system("cls");      // clear screen
            break;

        case '2':
            system("cls");      // clear screen
            printTreeInOrder(T);        // printing the tree to the screen in-order
            printf("\n\nPress any key to return to previous menu\n");
            getch();
            system("cls");      // clear screen
            break;

        case '3':
            system("cls");      // clear screen
            printTreePostOrder(T);      // printing the tree to the screen ppst-order
            printf("\n\nPress any key to return to previous menu\n");
            getch();
            system("cls");      // clear screen
            break;

        case '4': break;        // if '4' (exit choice) has chosen, then do nothing

        default:                // if any other option has chosen show an error message
            system("cls");      // clear screen
            printf("No such option! Enter your choice again please:\n\n");
        }

    }while (option != '4');     // exit this menu if '4' has chosen
}

void heightPrintingChoices(AVL T){

    char county[21];
    char option;

    do{
        printf("Counties:\n\n");
        printTreeInOrder(T);        // print tree in-order
        printf("\n");

        printf("1)Print the height of the root\n");                 // options
        printf("2)Print the height of a specific node(county)\n");;
        printf("3)Return to main menu\n");

        option = getch();               // getting user's option

        if (T == NULL && option != '3'){     /* if the tree is empty and the user tried to print it show error message
                                                (but don't show the error message if he wanted to exit)*/
            system("cls");              // clear screen
            printf("No data in the tree!\n\n");
            printf("press any key to return to previous menu\n");       // returning to previous menu
            getch();
            continue;       // continue used here to prevent continuing below
        }

        switch (option){

        case '1':
            system("cls");          // clear screen
            printf("The height of the tree is: %d\n\n\n", getHeight(T));        // printing the height of the root
            printf("\n\nPress any key to return to previous menu\n");
            getch();
            system("cls");          // clear screen
            break;

        case '2':
            system("cls");          // clear screen

            printf("Tree nodes:\n\n");
            printTreeInOrder(T);            // printing the tree in-order

            printf("\nEnter the county that you want to find the height at:\n");
            fflush(stdin);          // flushing the screen from previous '\n'
            gets(county);           // getting the county's name from the user

            AVL key = findCity(T, county);      // searching for that county in the tree

            printf("\n\n");

            if (key == NULL)                    // if key == NULL, then the county is not found, so print error message
                printf("No such county!\n");
            else                                // if found, print its height
                printf("The height of county \"%s\" is %d\n", key -> city, key -> height);

            printf("\n\nPress any key to return to previous menu\n");       // returning to previous menu
            getch();
            system("cls");      // clear screen
            break;

        case '3': break;        // if '3' (exit choice) has chosen, then do nothing

        default:
            system("cls");      // clear screen
            printf("No such option! Enter your choice again please:\n\n");
        }

    }while (option != '3');     // exit this menu if '3' has chosen
}
